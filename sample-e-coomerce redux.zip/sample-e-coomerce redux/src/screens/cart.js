// Cart.js
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCart } from '../app/cartSlice';

const Cart = () => {
  const cart = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();

  return (
    <div className="cart-page">
      <h2>Your Cart</h2>
      {cart.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <ul style={{ listStyle: "none" }}>
          {cart.map((item) => (
            <li key={item.id}>
              <h4><u>{item.title}</u></h4>
              <p>Price: ${item.price}</p>
              <img
                src={item.image}
                alt={item.title}
                style={{ height: '100px', objectFit: 'contain', border: '1px solid black' }}
              />
              <button
                onClick={() => dispatch(removeFromCart(item.id))}
                style={{ color: "cadetblue", borderRadius: "45px", marginLeft: "5%", width: "200px" }}
              >
                <b>Remove This Item From Cart</b>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Cart;
